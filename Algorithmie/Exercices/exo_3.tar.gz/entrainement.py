print("3.1 Entraînement")

print("boucles while :")
x = 1
while(x != 6):
    print(x," ", end="")
    x += 1
print()

y = 3
while(y != -3):
    print(y," ", end="")
    y = y-1
print()

z = 0
while(z != 105):
    print(z," ", end="")
    z += 5
print()

a = 10
while(a != -15):
    print(a," ", end="")
    a = a-5
print()

print("boucles for")
x = 1
for i in range(1,6):
    print(x," ", end="")
    x += 1
print()

y = 3
for i in range(1,7):
    print(y," ", end="")
    y = y-1
print()

z = 0
for i in range (1,22):
    print(z," ", end="")
    z += 5
print()

a = 10
for i in range(1,6):
    print(a," ", end="")
    a = a-5
print()

