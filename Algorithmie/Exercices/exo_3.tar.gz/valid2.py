print("""Exercice 3.2 : validation de donnees""")
chain = (input("donner une chaine de caracteres : "))
char = len(chain)
while(char == 0):
    chain = (input("donner une chaine de caracteres"))
print("Merci, fin du programme")
